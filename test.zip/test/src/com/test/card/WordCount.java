package com.test.card;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;

public class WordCount {
		//读取文件
		public static void largeFileIO(String inputFile,String outputfile) {
		FileWriter fw;
		BufferedInputStream bis;
		BufferedReader in;
        try {
             bis = new BufferedInputStream(new FileInputStream(new File(inputFile)));
             in = new BufferedReader(new InputStreamReader(bis, "utf-8"), 10 * 1024 * 1024);//10M缓存
            
            fw =new  FileWriter(outputfile);
            while (in.ready()) {
                String line = in.readLine();
               wordCount(line, fw);
            }
            fw.close();
            in.close();
            bis.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }   	
	}
	//word次数统计
	public static void wordCount(String line,FileWriter fw) throws IOException{
		  Map<String,Integer> map=new HashMap<String,Integer>();
		  StringTokenizer token=new StringTokenizer(line);//这个类会将字符串分解成一个个的标记 
		    while(token.hasMoreTokens()){                      //循环遍历                                    
		        String word=token.nextToken(", ?.!:\"\"''\n");  //括号里的字符的含义是说按照,空格 ? . : "" '' \n去分割，如果这里你没明确要求，即括号里为空，则默认按照空格，制表符，新行符和回车符去分割 
		        if(map.containsKey(word)){     //HashMap不允许重复的key，所以利用这个特性，去统计单词的个数 
		            int count=map.get(word); 
		            map.put(word, count+1);     //如果HashMap已有这个单词，则设置它的数量加1 
		        } 
		        else 
		            map.put(word, 1);          //如果没有这个单词，则新填入，数量为1 
		    }
		    sort(map, fw);
	}
	//排序
	public static void sort(Map<String,Integer> map,FileWriter fw) throws IOException{ 
	    List<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());  
	    Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {    
	        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {    
	            return (o2.getValue() - o1.getValue());    
	        }    
	}); //排序 
	    for (int i = 0; i < infoIds.size(); i++) {   //输出 
	        Entry<String, Integer> id = infoIds.get(i);
	        String str = id.getKey() +"\t" +id.getValue() +"\n";
	        fw.write(str);
	    } 
	} 
	
	public static void main(String[] args) {
		String inputFile = "";//文件路径
		String outputfile = "";
		largeFileIO(inputFile, outputfile);
	}
}
