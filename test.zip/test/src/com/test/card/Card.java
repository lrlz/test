package com.test.card;
/**
 * @author lrlz
 *扑克牌
 */
class Card {

	private static final String[] colors = {"红桃", "方块", "梅花", "黑桃"};
	private static final String[] values = {"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2"};
	
	private String[] newCard;
	private int cardNum;
	  //初始化52张牌
	  public Card() {
		cardNum = colors.length * values.length;
	    newCard = new String[cardNum];
	    int k = 0;
	    for (int i = 0; i < colors.length; i++) {
	      for (int j = 0; j < values.length; j++) {
	        newCard[k] = colors[i] + values[j];
	        k++;
	      }
	    }
	  }
	public int getCardNum() {
		return cardNum;
	}
	public String[] getNewCard() {
		return newCard;
	}	
}
