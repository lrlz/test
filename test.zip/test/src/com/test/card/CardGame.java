package com.test.card;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

class CardGame {
	HashMap<String, String> map = new HashMap<String, String>();
	public CardGame(){
	}
	Card card = new Card();
	private int cardNum = card.getCardNum();
	private String[] newCard = card.getNewCard();
	//洗牌(把牌打乱)
	  private void init() {
	    Random r = new Random();
	    int i = r.nextInt(cardNum);
	    String s;
	    if (i >= 0 && !map.containsKey(String.valueOf(i))) {
	      s = String.valueOf(i);
	      map.put(s, newCard[i]);
	    } else {
	      init();
	    }
	  }
	  //发牌
	  public void oneCard(int p) {
		    for (int i = 0; i < cardNum; i++) {
		      init();
		    }
		    int l = cardNum/p; //每人发几张牌
		    int j=1;//计人数
		    int k=0;//计牌数

		for (Map.Entry<String, String> entry : map.entrySet()) {
		      if(k%l==0 && j<=p){
		        System.out.println("第"+j+"个人的牌:");
		        j++;
		      } else if(cardNum-k <= cardNum%p){
		        System.out.println("剩余的牌:");
		      }
		      k++;

		System.out.println(entry.getValue());
		    }
	  }
}
