package com.test.card;

public class Player {

	public static void main(String[] args) {
		CardGame cg = new CardGame();//开始游戏
		cg.oneCard(4);//设置游戏人数
	}
	

}
